<? include("PGSQL_Login.class") ?>
<html>
<body>
<form>
<?
  $Access = New Access();
  if ( isset($Login) )
  {
    $acs = $Access->CreateLogin($database,$user,$pass,$host);
    if ( ! $acs )
    {
      echo("  <center><font size=\"6\">Error !</font><br>\n");
      echo("  <input type=\"submit\" value=\"Continue\"><center>\n");
      exit;
    }
  }
  elseif ( isset($Logout) )
    $Access->CloseLogin();
  $con = $Access->CheckLogin();
  if ( $con )
  {
    $user = $Access->CheckUser();
    echo("  <center><font size=\"6\">Login User: <b>$user</b></font><br>\n");
    echo("  <input type=\"submit\" name=\"Logout\" value=\"Logout\"></center>\n");
  }
  else
  {
?>
  <center>
  <table>
  <tr><td align="center" colspan="2"><font size="6">Login</font></td></tr>
  <tr><td align="right">User:</td><td><input name="user"></td></tr>
  <tr><td align="right">Pass:</td><td><input name="pass" type="password"></td></tr>
  <tr><td align="right">DB:</td><td><input name="database"></td></tr>
  <tr><td align="right">Host:</td><td><input name="host"></td></tr>
  <tr><td align="center" colspan="2"><input type="submit" name="Login" value="Login"></td></tr>
  </table>
<?
  }
?>
</form>
</body>
</html>